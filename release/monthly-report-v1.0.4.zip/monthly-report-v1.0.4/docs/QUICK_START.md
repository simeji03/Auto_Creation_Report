# クイックスタートガイド

## 1. Docker Desktopをインストール
- Mac: https://www.docker.com/products/docker-desktop/
- Windows: 同上

## 2. 起動
- Mac: START_HERE_MAC.command をダブルクリック
- Windows: START_HERE_WINDOWS.bat を右クリック→管理者として実行

## 3. 完了！
ブラウザが自動で開きます（http://localhost:3456）
